package com.project.MyZeneration_spring.service;

import org.springframework.stereotype.Service;

@Service
public class Standard {
	
	//각 항목 배열 - 갯수 많아지면 DB에 저장
	public final static String[] EDUCATIONLIST = {"대학원졸업","대학교졸업","고등학교졸업"};
	public final static String[] MAJORLIST = {"이학/공학","인문/사회","예체능"};
	public final static String[] REGIONLIST = {"서울특별시","부산광역시","광주광역시"};
	public final static String[] SALARYLIST = {"6000","5000","4000","3000","2000","1000"};
	public final static String[] FAMILYNOLIST = {"1","2","3","4","5"};
	public final static String[] RESIDENCELIST = {"자가","부모님과동거","전세","월세"};
	public final static String[] WORKINGHOURLIST = {"40시간미만","40~49시간","50~59시간","60시간이상"};
	public final static String[] MARRIAGELIST = {"기혼","미혼"};
	
	//각 항목에 대한 점수
	public final static int HIGHEST_EDU=12;
	public final static int HIGHEST_MAJOR=8;
	public final static int HIGHEST_REGION=10;
	public final static int HIGHEST_SALARY=17;
	public final static int HIGHEST_FAMILYNO=5;
	public final static int HIGHEST_RESIDENCE=13;
	public final static int HIGHEST_WORKINGHOUR=15;
	public final static int HIGHEST_MARRIAGE=5;
	
	public final static int EDUCATION_GRADUATESCHOOL = 12;
	public final static int EDUCATION_UNIVERSITY = 9;
	public final static int EDUCATION_HIGHSCHOOL = 6;
	
	public final static int MAJOR_SCIENCE = 8;
	public final static int MAJOR_SOCIETY = 5;
	public final static int MAJOR_ARTANDSPORTS = 3;
	
	public final static int REGION_SEOUL = 10;
	public final static int REGION_BUSAN = 8;
	public final static int REGION_GWANGJU = 6;
	
	public final static int SALARY_6000 = 17;
	public final static int SALARY_5000 = 15;
	public final static int SALARY_4000 = 13;
	public final static int SALARY_3000 = 9;
	public final static int SALARY_2000 = 5;
	public final static int SALARY_1000 = 2;
	
	public final static int FAMILYNO_5 = 5;
	public final static int FAMILYNO_4 = 5;
	public final static int FAMILYNO_3 = 4;
	public final static int FAMILYNO_2 = 4;
	public final static int FAMILYNO_1 = 2;
	
	public final static int RESIDENCE_BUYINGHOUSE = 13;
	public final static int RESIDENCE_LIVINGWITHPARENTES = 10;
	public final static int RESIDENCE_PAYINGANNUAL = 7;
	public final static int RESIDENCE_PAYINGAMONTHLY = 5;
	
	public final static int WORKINGHOUR_UNDER40 = 15;
	public final static int WORKINGHOUR_BETWEEN40AND49 = 14;
	public final static int WORKINGHOUR_BETWEEN50AND59 = 10;
	public final static int WORKINGHOUR_OVER60 = 6;
	
	
	public final static int MARRIAGE_MARRIED = 5;
	public final static int MARRIAGE_SINGLE = 3;

	
}
