package com.project.MyZeneration_spring.vo;

import lombok.Data;

@Data
public class NestedSelectionVO {
	
	private String[] sexList;
	private String[] ageList;
	private String[] lifeScoreList;

}
