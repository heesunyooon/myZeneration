package com.project.MyZeneration_spring.repository;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

public class Connector {
	
	Connection connection;
	PreparedStatement pstmt;
	ResultSet rs;
	String jdbc_driver = "oracle.jdbc.driver.OracleDriver";
	String jdbc_url = "jdbc:oracle:thin:@localhost:1521:xe";
	
	
	//DB연결
	public void connect() {
		try {
			System.out.println("DB connection success");
			Class.forName(jdbc_driver);
			connection = DriverManager.getConnection(jdbc_url, "scott", "tiger");
		}	catch(Exception e) {
			System.out.println("DB connection fail");
			e.printStackTrace();
		}
	}
	
	//DB연결해제
	public void disconnect() {
		if (pstmt !=null) {
			try {
				System.out.println("DB disconnection success");
				pstmt.close();
			}	catch(SQLException e) {
				e.printStackTrace();
			}
		}
			
		if(connection!=null) {
			try {
				connection.close();
			}catch(SQLException e) {
				e.printStackTrace();
			}
		}
	}

}
