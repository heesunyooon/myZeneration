package com.project.MyZeneration_spring.service;

public interface IMemberService {
	
}
