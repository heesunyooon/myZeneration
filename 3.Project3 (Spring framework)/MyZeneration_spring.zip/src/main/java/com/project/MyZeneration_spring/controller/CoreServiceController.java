package com.project.MyZeneration_spring.controller;

import java.util.List;

import javax.servlet.http.HttpSession;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseBody;

import com.project.MyZeneration_spring.service.CoreService;
import com.project.MyZeneration_spring.service.Standard;
import com.project.MyZeneration_spring.vo.ItemsVO;
import com.project.MyZeneration_spring.vo.NestedSelectionVO;

@Controller
@RequestMapping(value = "/core")
public class CoreServiceController {

	@Autowired
	CoreService coreService;

	Standard standard;

	@GetMapping("/analysisMySat")
	public String analysisMySat(@RequestParam(value = "memberId") String memberId, Model model, HttpSession session) {
		System.out.println("[Notice] CoreServiceController (analysisMySat)");
		model.addAttribute("memberInfo", coreService.getMemberInfo(memberId, session));
		model.addAttribute("educationList", Standard.EDUCATIONLIST);
		model.addAttribute("majorList", Standard.MAJORLIST);
		model.addAttribute("regionList", Standard.REGIONLIST);
		model.addAttribute("salaryList", Standard.SALARYLIST);
		model.addAttribute("familyNoList", Standard.FAMILYNOLIST);
		model.addAttribute("residenceList", Standard.RESIDENCELIST);
		model.addAttribute("workingHourList", Standard.WORKINGHOURLIST);
		model.addAttribute("marriageList", Standard.MARRIAGELIST);
		session.setAttribute("lifeScore", coreService.getMemberInfo(memberId, session).getLifeScore());
		return "analysisMySat";
	}

	@PostMapping("/updateRadarChart")
	public @ResponseBody List<List<String>> updateRadarChart(@RequestBody ItemsVO items) {
		System.out.println("[Notice] CoreServiceController (updateRadarChart)");
		return coreService.calculateRatio(items);
	}

	@PostMapping("/updateBarChart")
	public @ResponseBody List<List<String>> updateBarChart(@RequestBody ItemsVO items, HttpSession session) {
		System.out.println("[Notice] CoreServiceController (updateBarChart)");
		return coreService.recommend(items, session);
	}

	@GetMapping("/analysisMz")
	public String analysisMz() {
		System.out.println("[Notice] CoreServiceController (analysisMz)");
		return "analysisMz";
	}

	@PostMapping("/updateDoughnutChart")
	public @ResponseBody List<List<String>> updateDoughnutChart(@RequestBody NestedSelectionVO lists) {
		System.out.println("[Notice] CoreServiceController (updateDoughnutChart)");
		return coreService.getMzRatio(lists);
	}

	@PostMapping("/updateMySatScore")
	public @ResponseBody int updateMySatScore(@RequestBody ItemsVO items, HttpSession session) {
		System.out.println("[Notice] CoreServiceController (updateMySatScore)");
		int result = coreService.updateMySatScore(items, (String) session.getAttribute("memberId"), session);
		return result;
	}
}
