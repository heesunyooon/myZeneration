package com.project.MyZeneration_spring.repository;

import com.project.MyZeneration_spring.vo.ItemsVO;
import com.project.MyZeneration_spring.vo.MemberInfoVO;

public interface ICoreServiceRepository {

	MemberInfoVO getMemberInfo(String memberId);
	void getMzRatio (String[] sexList, String[] ageList, String[] lifeScore);
	void calculateRatio(ItemsVO items);
	void recommend(ItemsVO items);
	
	
}
