package com.project.MyZeneration_spring.vo;

import lombok.Data;

@Data
public class SurveyVO {

	private String sex;
	private int age;
	private String education;
	private String major;
	private String region;
	private int salary;
	private int familyNo;
	private String residence;
	private String workingHour;
	private String marriage;
	private int lifeScore;

}
