package com.project.MyZeneration_spring.vo;

import java.sql.Timestamp;

import lombok.Data;

@Data
public class BoardInsertVO {
	
	private int no;	
	private String bId;
	private String bTitle;
	private String bContent;
	private Timestamp bWriteDate;
	private int bHit;
	private int bGroup;
	private int bStep;
	private int bIndent;

	public BoardInsertVO() {}
	
	public BoardInsertVO(int no, String bId, String bTitle, String bContent, Timestamp bWriteDate, int bHit, int bGroup,
			int bStep, int bIndent) {
		super();
		this.no = no;
		this.bId = bId;
		this.bTitle = bTitle;
		this.bContent = bContent;
		this.bWriteDate = bWriteDate;
		this.bHit = bHit;
		this.bGroup = bGroup;
		this.bStep = bStep;
		this.bIndent = bIndent;
	}
	
}
