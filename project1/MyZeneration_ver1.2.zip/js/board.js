var posts = [
    {id: 1, title: "첫 번째 게시글", author: "Author 1", date: "2023-06-01", reply: "3", recommend: "2"},
    {id: 2, title: "Post 2", author: "Author 2", date: "2023-06-03", reply: "1", recommend: "4"},
    {id: 3, title: "제목이 overflow하는 경우 hidden", author: "Author 1", date: "2023-06-01", reply: "3", recommend: "2"},
    {id: 4, title: "엄청 긴 제목 오버플로우 경우 확인------------ 긴 제목", author: "Author 2", date: "2023-06-03", reply: "1", recommend: "4"},
    {id: 5, title: "Post 1", author: "Author 1", date: "2023-06-01", reply: "3", recommend: "2"},
    {id: 6, title: "Post 2", author: "Author 2", date: "2023-06-03", reply: "1", recommend: "4"},
    {id: 7, title: "Post 1", author: "Author 1", date: "2023-06-01", reply: "3", recommend: "2"},
    {id: 8, title: "Post 2", author: "Author 2", date: "2023-06-03", reply: "1", recommend: "4"},
    {id: 9, title: "Post 1", author: "Author 1", date: "2023-06-01", reply: "3", recommend: "2"},
    {id: 10, title: "Post 2", author: "Author 2", date: "2023-06-03", reply: "1", recommend: "4"},
    {id: 11, title: "Post 1", author: "Author 1", date: "2023-06-01", reply: "3", recommend: "2"},
    {id: 12, title: "Post 2", author: "Author 2", date: "2023-06-03", reply: "1", recommend: "4"},
    {id: 13, title: "Post 1", author: "Author 1", date: "2023-06-01", reply: "3", recommend: "2"},
    {id: 14, title: "Post 2", author: "Author 2", date: "2023-06-03", reply: "1", recommend: "4"},
    {id: 15, title: "제목이 overflow하는 경우 hidden이 되도록 만들었습니다.", author: "Author 1", date: "2023-06-01", reply: "3", recommend: "2"},
    {id: 16, title: "Post 2", author: "Author 2", date: "2023-06-03", reply: "1", recommend: "4"},
    {id: 17, title: "엄청 긴 제목 오버플로우 경우 확인하기 위한 엄청 길고 장대한 제목! 디따디따 긴 제목!!", author: "Author 1", date: "2023-06-01", reply: "3", recommend: "2"},
    {id: 18, title: "Post 2", author: "Author 2", date: "2023-06-03", reply: "1", recommend: "4"},
    {id: 19, title: "Post 1", author: "Author 1", date: "2023-06-01", reply: "3", recommend: "2"},
    {id: 20, title: "Post 2", author: "Author 2", date: "2023-06-03", reply: "1", recommend: "4"},
    {id: 21, title: "Post 1", author: "Author 1", date: "2023-06-01", reply: "3", recommend: "2"},
    {id: 22, title: "Post 2", author: "Author 2", date: "2023-06-03", reply: "1", recommend: "4"},
    {id: 23, title: "Post 1", author: "Author 1", date: "2023-06-01", reply: "3", recommend: "2"},
    {id: 24, title: "Post 2", author: "Author 2", date: "2023-06-03", reply: "1", recommend: "4"},
    {id: 25, title: "제목이 overflow하는 경우 hidden이 되도록 만들었습니다.", author: "Author 1", date: "2023-06-01", reply: "3", recommend: "2"},
    {id: 26, title: "Post 2", author: "Author 2", date: "2023-06-03", reply: "1", recommend: "4"},
    {id: 27, title: "Post 1", author: "Author 1", date: "2023-06-01", reply: "3", recommend: "2"},
    {id: 28, title: "Post 2", author: "Author 2", date: "2023-06-03", reply: "1", recommend: "4"},
    {id: 29, title: "Post 1", author: "Author 1", date: "2023-06-01", reply: "3", recommend: "2"},
    {id: 30, title: "엄청 긴 제목 오버플로우 경우 확인하기 위한 엄청 길고 장대한 제목! 디따디따 긴 제목!!", author: "Author 2", date: "2023-06-03", reply: "1", recommend: "4"},
    {id: 31, title: "Post 1", author: "Author 1", date: "2023-06-01", reply: "3", recommend: "2"},
    {id: 32, title: "Post 2", author: "Author 2", date: "2023-06-03", reply: "1", recommend: "4"},
    {id: 33, title: "Post 1", author: "Author 1", date: "2023-06-01", reply: "3", recommend: "2"},
    {id: 34, title: "Post 2", author: "Author 2", date: "2023-06-03", reply: "1", recommend: "4"},
    {id: 35, title: "제목이 overflow하는 경우 hidden이 되도록 만들었습니다.", author: "Author 1", date: "2023-06-01", reply: "3", recommend: "2"},
    {id: 36, title: "Post 2", author: "Author 2", date: "2023-06-03", reply: "1", recommend: "4"},
    {id: 37, title: "Post 1", author: "Author 1", date: "2023-06-01", reply: "3", recommend: "2"},
];

// prev와 next, 각 페이지네이션에 링크 달아주기.
// 글 작성에도 링크 달아주기.
// 데이터베이스에서 게시글 정보 가져오기.
// 댓글 정보에 관한 것은 추후 생각.

function boardPage(currentPage) { // 현재 페이지를 매개변수로 게시글/페이지네이션 표시.
   
    var tableBody = document.querySelector("#board-table tbody");
    tableBody.replaceChildren();
    
    let totalPost = posts.length; // 총 게시글 수
    let page_num = 10; // 페이지네이션 최대 수
    
    let totalPage = Math.ceil(totalPost / page_num); // 총 페이지네이션 수
    
    let pageGroup = Math.ceil(currentPage / page_num); // 현재 페이지가 몇 번째 그룹인지
    
    let lastPage = pageGroup * page_num;
    if (lastPage > totalPage) { lastPage = totalPage };
    let firstPage = lastPage - (page_num - 1);
    if (firstPage < 0) { firstPage = 1 };
    
    let pages = document.querySelector(".paginate .pageNo");
    pages.replaceChildren();
    
    for(let i = firstPage; i<=lastPage; i++) { // 페이지네이션 생성
        if (i==currentPage) {
            pages.innerHTML += `<button class="pageNumber currentPage" id="page_${i}">${i}</button>`
        } else pages.innerHTML += `<button class="pageNumber" id="page_${i}" onclick=boardPage(${i})>${i}</button>`
    }
  
    for (var i = totalPost-(currentPage-1)*10-1; i>totalPost-(currentPage*10)-1; i--) { // 글 생성
        var row = document.createElement("tr");

        var idCell = document.createElement("th"); // 글 번호
        idCell.setAttribute('class', 'text-center no');
        idCell.textContent=posts[i].id;
        idCell.scope="row"; 

        var titleCell = document.createElement("td"); // 글 제목
        titleCell.setAttribute('class', 'title');
        titleCell.innerHTML = `<a href="sub-board-watch.html">` + posts[i].title + "</a>";

        var authorCell = document.createElement("td"); // 글쓴이
        authorCell.setAttribute('class', 'text-center author');
        authorCell.textContent = posts[i].author;

        var dateCell = document.createElement("td"); // 작성일
        dateCell.setAttribute('class', 'text-center date');
        dateCell.textContent = posts[i].date;

        var replyCell = document.createElement("td"); // 댓글 수 (count로 조정 필요?)
        replyCell.setAttribute('class', 'text-center reply');
        replyCell.textContent = posts[i].reply;

        var recommendCell = document.createElement("td"); // 추천 수
        recommendCell.setAttribute('class', 'text-center recommend');
        recommendCell.textContent = posts[i].recommend;

        row.appendChild(idCell);
        row.appendChild(titleCell);
        row.appendChild(authorCell);
        row.appendChild(dateCell);
        row.appendChild(replyCell);
        row.appendChild(recommendCell);

        tableBody.appendChild(row);
    }
}

window.onload = boardPage(1);