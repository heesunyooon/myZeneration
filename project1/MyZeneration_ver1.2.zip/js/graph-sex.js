let firstGraph = document.querySelectorAll('.contents');

  firstGraph.forEach(function (d) { // 그래프 두 배로 만들기
    let secondGraph = document.createElement(`div`); // div 태그 생성
    let att = document.createAttribute(`class`) // 기존 그래프 class 속성 복사
    att.value = d.getAttribute(`class`) // 복사
    secondGraph.setAttributeNode(att); // 새 div 태그에 넣기
    let graphHTML = d.innerHTML; // 기존 소스 복사
    secondGraph.innerHTML = graphHTML; // 기존 소스 붙여넣기
    console.log(d)
    console.log(secondGraph)
    secondGraph.querySelector(".graphTotal").querySelector("canvas").id = `${d.querySelector(".graphTotal").querySelector("canvas").id}S` // 새 그래프 ID 뒤에 S 넣어주기
    $(function () { // 기존 소스 뒤에 연결
      $(secondGraph).insertAfter(d);
    });
  }
  )
// SexGraph 함수는 male 그래프, female 그래프 따로 그림!
// labels에 만족도를 넣음!

function makeSexGraph() {

  // !important! ▼▼▼▼▼▼▼▼▼▼▼▼▼▼▼▼▼▼▼▼▼▼▼▼▼▼▼▼▼▼▼▼▼▼▼▼▼▼▼▼▼▼▼▼▼▼▼▼▼▼▼▼▼▼▼▼▼▼▼▼▼▼▼▼▼▼▼▼▼▼▼▼▼▼▼▼▼▼▼▼▼▼▼▼▼▼
  // check 요소 확인하는 임시 설정!! 추후 제대로 변경할 것!!
  // sex = 1 age = 2 edu = 3 region = 4 marriage = 5
  // firmSize = 6 firmType = 7 정규직/비정규직 여부 = 8

  // 카테고리 배열 생성 (size:2)
  // 이후 .checked로 체크 요소 확인(class별)하여 ${각 배열}에 넣고, True 존재시 category 배열에 넣기
  // categooy ==2인 경우 -> true >=2 인 category가 mainCategory, 나머진 subCategory
  // category ==1인 경우 => 그 하나뿐인 카테고리가 main
  // sortedData에 .filter(function(d) {return d.xxx='1'}) 식으로 분류 가능
  // 은 하나 생각해보니, 이건 DB 연동 후 SQL문으로 긁어오면 되는 거였음 ㅡㅡ
  // 아래도 DB 연동으로 해결하면 될 듯? 아님 말고
  // 서브 카테고리 따로 지정 잊지 말기.

  if (true) {
    var category = 1;
  } else if (false) {
    var category = 2;
  } else if (false) {
    var category = 3;
  } else if (false) {
    var category = 4;
  } else if (false) {
    var category = 5;
  } else if (true) {
    var category = 6;
  } else if (false) {
    var category = 7;
  } else if (false) {
    var category = 8;
  }

  // 각 요소 별 세부 체크 요소도 확인할 것.
  // 세부 체크 요소가 2개 이상인 카테고리를 main으로,
  // 하나인 카테고리를 sub로.
  // 아래 OOO if문에 넣어주어야 함.

  // !important! ▲▲▲▲▲▲▲▲▲▲▲▲▲▲▲▲▲▲▲▲▲▲▲▲▲▲▲▲▲▲▲▲▲▲▲▲▲▲▲▲▲▲▲▲▲▲▲▲▲▲▲▲▲▲▲▲▲▲▲▲▲▲▲▲▲▲▲▲▲▲▲▲▲▲▲▲▲▲▲▲▲▲▲▲▲▲

  // !important! ▼▼▼▼▼▼▼▼▼▼▼▼▼▼▼▼▼▼▼▼▼▼▼▼▼▼▼▼▼▼▼▼▼▼▼▼▼▼▼▼▼▼▼▼▼▼▼▼▼▼▼▼▼▼▼▼▼▼▼▼▼▼▼▼▼▼▼▼▼▼▼▼▼▼▼▼▼▼▼▼▼▼▼▼▼▼

  d3.csv("./treatedData_total_last.csv") // CSV 파일 로드. 추후 DB에서 끌어오기로 변경 요망!!
    .then(function (data) {
      var maleData = d3.group(data.filter(function (d) { // 성별 데이터는 따로따로 만듦!
        return (d.sex == '1') && (d.region == '1'); // 카테고리 이후 사용자 입력 받아야 함에 유의
      }), d => d.sex)
      var femaleData = d3.group(data.filter(function (d) { // 성별 데이터는 따로따로 만듦!
        return (d.sex == '2') && (d.region == '1'); //카테고리 이후 사용자 입력 받아야 함에 유의
      }), d => d.sex)
      var sortData = [maleData, femaleData]; // sort[0], [1]로 나누어 남/녀 객체 분리.

      // !important! ▲▲▲▲▲▲▲▲▲▲▲▲▲▲▲▲▲▲▲▲▲▲▲▲▲▲▲▲▲▲▲▲▲▲▲▲▲▲▲▲▲▲▲▲▲▲▲▲▲▲▲▲▲▲▲▲▲▲▲▲▲▲▲▲▲▲▲▲▲▲▲▲▲▲▲▲▲▲▲▲▲▲▲▲▲▲

      for (let j = 0; j < 2; j++) {
        if (j == 0) {
          var sexs = '남';
        } else var sexs = '여';

        // ★★★★★만족도 그래프 코드 시작!★★★★★

        const sat_order = new Array("workTotal", "spareTime", "lifeTotal"); // 템플릿 리터럴에 사용할 배열.

        for (let i = 0; i < sat_order.length; i++) { // 세 개 생성.
          var chartData = {
            labels: ['매우 불만족', '불만족', '보통', '만족', '매우 만족'], // x축 레이블
            datasets: [{ // 데이터 외형 설정
              data: [], // 아래의 push를 통해 데이터 받음.
              backgroundColor: [ // 막대바 색상       
                'rgba(255, 99, 132, 0.2)',
                'rgba(255, 206, 86, 0.2)',
                'rgba(75, 192, 192, 0.2)',
                'rgba(54, 162, 235, 0.2)',
                'rgba(153, 102, 255, 0.2)'
              ],
              borderColor: [ // 막대 테두리 색상              
                'rgba(255, 99, 132, 1)',
                'rgba(255, 206, 86, 1)',
                'rgba(75, 192, 192, 1)',
                'rgba(54, 162, 235, 1)',
                'rgba(153, 102, 255, 1)'
              ],
              borderWidth: 1 // 테두리 두께
            }]
          };

          if (j == 0) {
            var ctx = document.querySelector(`#${sat_order[i]}Chart`).getContext('2d');
          } else if (j == 1) {
            var ctx = document.querySelector(`#${sat_order[i]}ChartS`).getContext('2d');
          }

          sortData[j].forEach(function (values) {
            let count = new Array(chartData.labels.length);
            for (let b = 0; b < count.length; b++) {
              count[b] = 0;
            }
            values.forEach(function (d) {
              if (i == 0) { // 여기만은 템플릿 리터럴로 처리할 수 없어 if문 처리.
                for (let b = 0; b < count.length; b++) {
                  if (d.sat_workTotal == b + 1) {
                    count[b]++
                  }
                }
              } else if (i == 1) {
                for (let b = 0; b < count.length; b++) {
                  if (d.sat_spareTime == b + 1) {
                    count[b]++
                  }
                }
              } else if (i == 2) {
                for (let b = 0; b < count.length; b++) {
                  if (d.sat_lifeTotal == b + 1) {
                    count[b]++
                  }
                }
              }
            });
            let sum = 0;
            for (let b = 0; b < count.length; b++) {
              sum += count[b];
            }

            for (let b = 0; b < count.length; b++) {
              chartData.datasets[0].data.push(Math.round(count[b] / sum * 10000) / 100); // 데이터 입력.
            }
          });

          // 그래프 생성
          var myChart = new Chart(ctx, { // 그래프 생성용 변수라 원래 안 쓰이는 게 맞음.
            type: 'doughnut',
            data: chartData,
            options: {
              title: {
                display: true,
                text: `${sexs}`,
                fontColor: '#127',
                fontSize: 16,
                align: `center`
              },
              responsive: true,
              cutoutPercentage: 0, // 중앙 구멍 크기
              aspectRatio: 2.5, // 가로 : 세로(1) 비율
              legend: {
                display: true, // 범례 표시 ON. 반응형으로 일정 크기 이하에서 false 할 것.
                position: `bottom`, // 범례 우측에 배치
                reverse: true, // 역순
                labels: {
                    boxWidth: 10, // 범례박스 크기
                    textSize:10
                }
              },
              rotation: -0.25 * Math.PI, // 호를 그릴 시작 각도
              layout: {
                padding: 10
              }
            }
          });
        } // Sat_for문 종료.

        // 만족도 그래프 코드 끝!

        // ★★★★★노동 관련 그래프 코드 시작!★★★★★

        const aboutWork = new Array("wage", "workingHour"); // 템플릿 리터럴에 사용할 배열.

        for (let i = 0; i < aboutWork.length; i++) { // work 그래프 두 개 생성.
          if (i == 0) {
            var sortLabels = ['50만원 미만', '50~99만원', '100~149만원', '150~199만원', '200~249만원', '250~299만원', '300만원 이상']; // 데이터 입력.
          } else if (i == 1) {
            var sortLabels = ['30시간 미만', '30~39시간', '40~49시간', '50~59시간', '60~69시간', '70시간 이상']; // 데이터 입력.
          }

          var chartData = {
            labels: [], // x축 레이블
            datasets: [{ // 데이터 외형 설정
              data: [], // 아래의 push를 통해 데이터 받음.
              backgroundColor: [ // 막대바 색상       
                'rgba(255, 99, 132, 0.2)',
                'rgba(255, 159, 64, 0.2)',
                'rgba(255, 206, 16, 0.2)',
                'rgba(75, 192, 192, 0.2)',
                'rgba(54, 162, 235, 0.2)',
                'rgba(153, 102, 255, 0.2)',
                'rgba(123, 18, 82, 0.2)'
              ],
              borderColor: [ // 막대 테두리 색상              
                'rgba(255, 99, 132, 1)',
                'rgba(255, 159, 64, 1)',
                'rgba(255, 206, 16, 1)',
                'rgba(75, 192, 192, 1)',
                'rgba(54, 162, 235, 1)',
                'rgba(153, 102, 255, 1)',
                'rgba(123, 18, 82, 1)'
              ],
              borderWidth: 1 // 테두리 두께
            }]
          };

          if (j == 0) {
            var ctx = document.querySelector(`#${aboutWork[i]}Chart`).getContext('2d');
          } else if (j == 1) {
            var ctx = document.querySelector(`#${aboutWork[i]}ChartS`).getContext('2d');
          }

          for (let a = 0; a < sortLabels.length; a++) {
            chartData.labels.push(sortLabels[a]); // 만들어놓은 라벨 추가.
          }

          sortData[j].forEach(function (values) {
            let count = new Array(chartData.labels.length);
            for (let b = 0; b < count.length; b++) {
              count[b] = 0;
            }
            values.forEach(function (d) {
              if (i == 0) { // 여기만은 템플릿 리터럴로 처리할 수 없어 if문 처리.
                for (let b = 0; b < count.length; b++) {
                  if (b == count.length - 1) {
                    if (300 <= d.wage) {
                      count[b]++
                    }
                  } else {
                    if (b * 50 <= d.wage && d.wage < (b + 1) * 50) {
                      count[b]++
                    }
                  }
                }
              } else if (i == 1) {
                for (let b = 0; b < count.length; b++) {
                  if (b == 0) {
                    if (d.workingHour < 30) {
                      count[b]++
                    }
                  } else if (b == count.length - 1) {
                    if (d.workingHour < 30) {
                      count[b]++
                    }
                  } else { }
                  if (b * 10 + 20 <= d.workingHour && d.workingHour < (b * 10 + 29)) {
                    count[b]++
                  }
                }
              }
            });
            let sum = 0;
            for (let b = 0; b < count.length; b++) {
              sum += count[b];
            }

            for (let b = 0; b < count.length; b++) {
              chartData.datasets[0].data.push(Math.round(count[b] / sum * 10000) / 100); // 데이터 입력.
            }
          });

          // 그래프 생성
          var myChart = new Chart(ctx, { // 그래프 생성용 변수라 원래 안 쓰이는 게 맞음.
            type: 'doughnut',
            data: chartData,
            options: {
              title: {
                display: true,
                text: `${sexs}`,
                fontColor: '#127',
                fontSize: 16,
                align: `center`
              },
              responsive: true,
              cutoutPercentage: 0, // 중앙 구멍 크기
              aspectRatio: 2.5, // 가로 : 세로(1) 비율
              legend: {
                display: true, // 범례 표시 ON. 반응형으로 일정 크기 이하에서 false 할 것.
                position: `bottom`, // 범례 우측에 배치
                reverse: true, // 역순
                labels: {
                    boxWidth: 10, // 범례박스 크기
                    textSize:10
                }
              },
              rotation: -0.25 * Math.PI, // 호를 그릴 시작 각도
              layout: {
                padding: 10
              }
            }
          });
        } // work_for문 종료

        // 노동 관련 그래프 코드 끝!

        // ★★★★★삶 안정도 관련 그래프 코드 시작!★★★★★

        const lifeStable = new Array("fullTime", "marriage"); // 템플릿 리터럴에 사용할 배열.

        for (let i = 0; i < lifeStable.length; i++) { // 두 개 생성.
          if (i == 0) {
            var sortLabels = ['정규직', '비정규직']; // 데이터 입력.
          } else if (i == 1) {
            var sortLabels = ['미혼', '기혼']; // 데이터 입력.
          }
          var chartData = {
            labels: [], // x축 레이블
            datasets: [{ // 데이터 외형 설정
              data: [], // 아래의 push를 통해 데이터 받음.
              backgroundColor: [ // 막대바 색상       
                'rgba(255, 99, 132, 0.2)',
                'rgba(153, 102, 255, 0.2)'
              ],
              borderColor: [ // 막대 테두리 색상              
                'rgba(255, 99, 132, 1)',
                'rgba(153, 102, 255, 1)'
              ],
              borderWidth: 1 // 테두리 두께
            }]
          };

          if (j == 0) {
            var ctx = document.querySelector(`#${lifeStable[i]}Chart`).getContext('2d');
          } else if (j == 1) {
            var ctx = document.querySelector(`#${lifeStable[i]}ChartS`).getContext('2d');
          }

          for (let a = 0; a < sortLabels.length; a++) {
            chartData.labels.push(sortLabels[a]); // 만들어놓은 라벨 추가.
          }

          sortData[j].forEach(function (values) {
            let count = new Array(chartData.labels.length);
            for (let b = 0; b < count.length; b++) {
              count[b] = 0;
            }
            values.forEach(function (d) {
              if (i == 0) { // 여기만은 템플릿 리터럴로 처리할 수 없어 if문 처리.
                for (let b = 0; b < count.length; b++) {
                  if (d.fullTime == b + 1) {
                    count[b]++
                  }
                }
              } else if (i == 1) {
                for (let b = 0; b < count.length; b++) {
                  if (d.marriage == b + 1) {
                    count[b]++
                  }
                }
              }
            });
            let sum = 0;
            for (let b = 0; b < count.length; b++) {
              sum += count[b];
            }

            for (let b = 0; b < count.length; b++) {
              chartData.datasets[0].data.push(Math.round(count[b] / sum * 10000) / 100); // 데이터 입력.
            }
          });

          // 그래프 생성
          var myChart = new Chart(ctx, { // 그래프 생성용 변수라 원래 안 쓰이는 게 맞음.
            type: 'doughnut',
            data: chartData,
            options: {
              title: {
                display: true,
                text: `${sexs}`,
                fontColor: '#127',
                fontSize: 16,
                align: `center`
              },
              responsive: true,
              cutoutPercentage: 0, // 중앙 구멍 크기
              aspectRatio: 2.5, // 가로 : 세로(1) 비율
              legend: {
                display: true, // 범례 표시 ON. 반응형으로 일정 크기 이하에서 false 할 것.
                position: `bottom`, // 범례 우측에 배치
                reverse: true, // 역순
                labels: {
                    boxWidth: 10, // 범례박스 크기
                    textSize:10
                }
              },
              rotation: -0.25 * Math.PI, // 호를 그릴 시작 각도
              layout: {
                padding: 10
              }
            }
          });
        } // Sable_for문 종료.

        // 삶 안정도 관련 그래프 코드 끝!

        // ★★★★★기업 규모 관련 그래프 코드 시작!★★★★★
        // 단일 그래프이므로 for문 X. for문 사용 위해 필요했던 템플릿 리터럴용 배열 X.

        var chartData = {
          labels: [`10명 미만`, `10명~29명`, `30명~99명`, `100명~299명`, `300명~499명`, `500명 이상`], // x축 레이블.
          datasets: [{ // 데이터 외형 설정
            label: [], // 그래프 이름
            data: [], // 아래의 push를 통해 데이터 받음.
            backgroundColor: [
              'rgba(255, 99, 132, 0.2)',
              'rgba(255, 159, 64, 0.2)',
              'rgba(255, 206, 16, 0.2)',
              'rgba(75, 192, 192, 0.2)',
              'rgba(54, 162, 235, 0.2)',
              'rgba(153, 102, 255, 0.2)'
            ], // 막대 바 색상. 각기 다르게 설정하려면 배열로 만들 것.
            borderColor: [
              'rgba(255, 99, 132, 1)',
              'rgba(255, 159, 64, 1)',
              'rgba(255, 206, 16, 1)',
              'rgba(75, 192, 192, 1)',
              'rgba(54, 162, 235, 1)',
              'rgba(153, 102, 255, 1)'
            ], // 막대 테두리 색상.
            borderWidth: 1 // 테두리 두께
          }]
        };

        if (j == 0) {
          var ctx = document.querySelector(`#firmSizeChart`).getContext('2d');
        } else if (j == 1) {
          var ctx = document.querySelector(`#firmSizeChartS`).getContext('2d');
        }

        sortData[j].forEach(function (values) {
          let count = new Array(chartData.labels.length);
          for (let b = 0; b < count.length; b++) {
            count[b] = 0;
          }
          values.forEach(function (d) {
            for (let b = 0; b < count.length; b++) {
              if (d.firmSize == b + 1) {
                count[b]++
              }
            }
          });
          let sum = 0;
          for (let b = 0; b < count.length; b++) {
            sum += count[b];
          }
          for (let b = 0; b < count.length; b++) {
            chartData.datasets[0].data.push(Math.round(count[b] / sum * 10000) / 100); // 데이터 입력.
          }
        });

        // 그래프 생성
        var myChart = new Chart(ctx, { // 그래프 생성용 변수라 원래 안 쓰이는 게 맞음.
          type: 'doughnut',
          data: chartData,
          options: {
            title: {
              display: true,
              text: `${sexs}`,
              fontColor: '#127',
              fontSize: 16,
              align: `center`
            },
            responsive: true,
            cutoutPercentage: 0, // 중앙 구멍 크기
            aspectRatio: 2.5, // 가로 : 세로(1) 비율
            legend: {
              display: true, // 범례 표시 ON. 반응형으로 일정 크기 이하에서 false 할 것.
              position: `bottom`, // 범례 우측에 배치
              reverse: true, // 역순
              labels: {
                  boxWidth: 10, // 범례박스 크기
                  textSize:10
              }
            },
            rotation: -0.25 * Math.PI, // 호를 그릴 시작 각도
            layout: {
              padding: 10
            }
          }
        });

        // 기업 규모 관련 그래프 코드 끝!
      }

    })
    .catch(function (error) {
      // 파일 로드 오류 처리
      console.log("파일 로드 오류:", error);
    });
}

makeSexGraph();