$.fn.isInViewport = function() {
    var elementTop = $(this).offset().top;
    var elementBottom = elementTop + $(this).outerHeight();

    var viewportTop = $(window).scrollTop();
    var viewportBottom = viewportTop + $(window).height();

    return elementBottom > viewportTop + 50 && elementTop < viewportBottom -50;

};

$(window).on('load resize scroll',function(){
    $('.ani').each(function(){
        if($(this).isInViewport()){
            $(this).addClass('active');
        }
    });
});

/*메인화면 텍스트 애니메이션*/
let text=(document.querySelector(".text-typing"));
let liLength=text.length;
let typingIdx=0;
let liIdx=0;
const letters = [
    'I am happy now!',
    'I am good.',
    'I am depressed.',
    'Not that bad.',
    'I don\'t know.'
];

function typing(){
        if(typingIdx<letters[liIdx].length){
            ++typingIdx;
            text.innerText=letters[liIdx].slice(0,typingIdx);
        }
        else if (liIdx>=letters.length-1){
            liIdx=0;
            typingIdx=0;
        }
        else {
            liIdx++;
            typingIdx=0;
        }
}
let timer = setInterval(typing,160);


//
const button1 = document.getElementById('button1');
const section1 = document.getElementById('section1');

button1.addEventListener('click', () => {
window.scrollBy({top: section1.getBoundingClientRect().top, behavior: 'smooth'});
});

//스크롤 내릴 때 마다 페이지 이동
window.onload = function(){
    const elm = document.querySelectorAll('.section');
    const elmCount = elm.length;
    elm.forEach(function(item, index){
      item.addEventListener('mousewheel', function(event){
        event.preventDefault();
        let delta = 0;

        if (!event) event = window.event;
        if (event.wheelDelta) {
            delta = event.wheelDelta / 120;
            if (window.opera) delta = -delta;
        } 
        else if (event.detail)
            delta = -event.detail / 3;

        let moveTop = window.scrollY;
        let elmSelector = elm[index];

        // wheel down : move to next section
        if (delta < 0){
          if (elmSelector !== elmCount-1){
            try{
              moveTop = window.pageYOffset + elmSelector.nextElementSibling.getBoundingClientRect().top;
            }catch(e){}
          }
        }
        // wheel up : move to previous section
        else{
          if (elmSelector !== 0){
            try{
              moveTop = window.pageYOffset + elmSelector.previousElementSibling.getBoundingClientRect().top;
            }catch(e){}
          }
        }

        const body = document.querySelector('html');
        window.scrollTo({top:moveTop, left:0, behavior:'smooth'});
      });
    });
  }



