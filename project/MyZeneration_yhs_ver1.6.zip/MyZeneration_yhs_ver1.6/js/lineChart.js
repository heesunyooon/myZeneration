//성별 변경
var dataSex = {
        labels: ['20', '30', '40', '50', '60'], //x축 배열
        datasets: [
                {
                        label: '남자',
                        data: [89, 87, 81, 85, 76],  //y축 배열
                        fill: false,
                        borderColor: 'rgb(7, 77, 129)',
                        tension: 0.1,
                        pointRadius: 1,
                        pointStyle:'rect',
                        pointBackgroundColor:'rgb(7, 77, 129)',
                 },{
                        label: '여자',
                        data: [85, 91, 85, 84, 80],
                        fill: false,
                        borderColor: 'rgb(64, 178, 230)',
                        tension: 0.1, 
                        pointRadius: 1,
                        pointStyle:'rect',
                        pointBackgroundColor:'rgb(64, 178, 230)',
                },
        ]
};

var changeSex = document.getElementById('changeSex').getContext('2d');
var myChart = new Chart(changeSex, {
type: 'line', 
data: dataSex,
options: {
       scales:{
        
        yAxes: [{
                thicks:{
                        display:true,
                        min:10,
                        max:100,
                        stepSize:10
                }
        }]
       },
       legend:{
                position:'bottom',
                labels:{
                        usePointStyle:true,
                }
       }
}
});
//-----------------------------------------



//학력 변경
var dataEdu = {
        labels: ['20', '30', '40', '50', '60'],
        datasets: [
        {
                label: '고등학교졸업',
                data: [71, 75, 81, 85, 81],
                fill: false,
                borderColor: 'rgb(7, 77, 129)',
                tension: 0.1,
                pointRadius: 1,
                pointStyle:'rect',
                pointBackgroundColor:'rgb(7, 77, 129)',
        },{
                label: '대학교(2,3,4년제) 졸업',
                data: [75, 71, 64, 72, 80],
                fill: false,
                borderColor: 'rgb(64, 178, 230)',
                tension: 0.1,
                pointRadius: 1,
                pointStyle:'rect',
                pointBackgroundColor:'rgb(64, 178, 230)',
        },{
                label: '대학원 졸업',
                data: [40, 59, 91, 81, 56],
                fill: false,
                borderColor: 'rgb(87, 64, 247)',
                tension: 0.1,
                pointRadius: 1,
                pointStyle:'rect',
                pointBackgroundColor:'rgb(87, 64, 247)',
        },
        ]
        };

var changeEdu = document.getElementById('changeEdu').getContext('2d');
var myChart = new Chart(changeEdu, {
type: 'line', 
data: dataEdu,
options: {
        scales:{
         
         yAxes: [{
                 thicks:{
                         display:true,
                         min:10,
                         max:100,
                         stepSize:10
                 }
         }]
        },
        legend:{
                 position:'bottom',
                 labels:{
                         usePointStyle:true,
                 }
        }
 }
});
//-----------------------------------------


//전공 변경
var dataEdu = {
        labels: ['20', '30', '40', '50', '60'],
        datasets: [
        {
                label: '인문/사회',
                data: [70, 61, 75, 80, 75],
                fill: false,
                borderColor: 'rgb(7, 77, 129)',
                tension: 0.1,
                pointRadius: 1,
                pointStyle:'rect',
                pointBackgroundColor:'rgb(7, 77, 129)',
        },{
                label: '이학/공학',
                data: [87, 89, 75, 80, 81],
                fill: false,
                borderColor: 'rgb(64, 178, 230)',
                tension: 0.1,
                pointRadius: 1,
                pointStyle:'rect',
                pointBackgroundColor:'rgb(64, 178, 230)',
        },{
                label: '예체능',
                data: [75, 62, 70, 81, 71],
                fill: false,
                borderColor: 'rgb(87, 64, 247)',
                tension: 0.1,
                pointRadius: 1,
                pointStyle:'rect',
                pointBackgroundColor:'rgb(87, 64, 247)',
        },
        ]
        };
var changeMajor = document.getElementById('changeMajor').getContext('2d');
var myChart = new Chart(changeMajor, {
type: 'line', 
data: dataEdu,
options: {
        scales:{
         
         yAxes: [{
                 thicks:{
                         display:true,
                         min:10,
                         max:100,
                         stepSize:10
                 }
         }]
        },
        legend:{
                 position:'bottom',
                 labels:{
                         usePointStyle:true,
                 }
        }
 }
});
//-----------------------------------------



//거주지역 변경
var dataEdu = {
        labels: ['20', '30', '40', '50', '60'],
        datasets: [
        {
                label: '서울특별시',
                data: [74, 84, 90, 91, 89],
                fill: false,
                borderColor: 'rgb(7, 77, 129)',
                tension: 0.1,
                pointRadius: 1,
                pointStyle:'rect',
                pointBackgroundColor:'rgb(7, 77, 129)',
        },{
                label: '부산광역시',
                data: [65, 70, 85, 83, 75],
                fill: false,
                borderColor: 'rgb(64, 178, 230)',
                tension: 0.1,
                pointRadius: 1,
                pointStyle:'rect',
                pointBackgroundColor:'rgb(64, 178, 230)',
        },{
                label: '광주광역시',
                data: [40, 59, 80, 81, 56],
                fill: false,
                borderColor: 'rgb(87, 64, 247)',
                tension: 0.1,
                pointRadius: 1,
                pointStyle:'rect',
                pointBackgroundColor:'rgb(87, 64, 247)',
        },
        ]
        };

var changeLocation = document.getElementById('changeLocation').getContext('2d');
var myChart = new Chart(changeLocation, {
type: 'line', 
data: dataEdu,
options: {
        scales:{
         
         yAxes: [{
                 thicks:{
                         display:true,
                         min:10,
                         max:100,
                         stepSize:10
                 }
         }]
        },
        legend:{
                 position:'bottom',
                 labels:{
                         usePointStyle:true,
                 }
        }
 }
});
//--
//-----------------------------------------





// //성별변경
// var dataSex = {
//         labels: ['20', '30', '40', '50', '60'],
//         datasets: [
//                 {
//                 label: 
//                 data: [78, 65, 87, 81, 76],
//                 fill: false,
//                 borderColor: 'rgb(7,77,129)',
//                 tension: 0.1
//         },{
//                 label: '여',
//                 data: [80, 81, 78, 62, 75],
//                 fill: false,
//                 borderColor: 'rgb(87,64,247)',
//                 tension: 0.1
//         }
//         ]
//         };
// var chartSex = document.getElementById('changeSex').getContext('2d');
// var myChart = new Chart(chartSex, {
//         type: 'line', 
//         data: dataSex,
//         options: {}
// });


// //학력변경시
// var chartEdu = document.getElementById('changeEdu').getContext('2d');
// var myChart = new Chart(chartEdu, {
// type: 'line', 
// data: dataEdu,
// options: {}
// });
// var dataEdu = {
//     labels: ['20', '30', '40', '50', '60'],
//     datasets: [
//         {
//             label: '고등학교 졸업',
//             data: [64, 68, 72, 74, 67],
//             fill: false,
//             borderColor: 'rgb(7, 77, 129)',
//             tension: 0.1
//     },{
//             label: '대학교 (2,3,4년제) 졸업',
//             data: [80, 81, 78, 62, 75],
//             fill: false,
//             borderColor: 'rgb(103, 113, 220)',
//             tension: 0.1
//     },{
//             label: '대학원 졸업',
//             data: [74, 84, 81, 78, 81],
//             fill: false,
//             borderColor: 'rgb(87, 64, 247)',
//             tension: 0.1
//     }
// ]
// };



// //전공변경시
// var chartMajor = document.getElementById('changeMajor').getContext('2d');
// var myChart = new Chart(chartMajor, {
// type: 'line', 
// data: dataMajor,
// options: {}
// });
// var dataMajor = {
//     labels: ['20', '30', '40', '50', '60'],
//     datasets: [
//         {
//             label: '인문/사회',
//             data: [64, 72, 69, 70, 68],
//             fill: false,
//             borderColor: 'rgb(7, 77, 129)',
//             tension: 0.1
//     },{
//             label: '이학/공학',
//             data: [80, 81, 78, 62, 75],
//             fill: false,
//             borderColor: 'rgb(103, 113, 220)',
//             tension: 0.1
//     },{
//             label: '예체능',
//             data: [74, 84, 81, 78, 81],
//             fill: false,
//             borderColor: 'rgb(87, 64, 247)',
//             tension: 0.1
//     }
// ]
// };

// //거주지역 변경시
// var chartLocation = document.getElementById('changeLocation').getContext('2d');
// var myChart = new Chart(chartLocation, {
// type: 'line', 
// data: dataLocation,
// options: {}
// });
// var dataLocation = {
//     labels: ['20', '30', '40', '50', '60'],
//     datasets: [
//         {
//             label: '서울특별시',
//             data: [64, 72, 69, 70, 68],
//             fill: false,
//             borderColor: 'rgb(7, 77, 129)',
//             tension: 0.1
//     },{
//             label: '부산광역시',
//             data: [80, 81, 78, 62, 75],
//             fill: false,
//             borderColor: 'rgb(103, 113, 220)',
//             tension: 0.1
//     },{
//             label: '광주광역시',
//             data: [74, 84, 81, 78, 81],
//             fill: false,
//             borderColor: 'rgb(87, 64, 247)',
//             tension: 0.1
//     }
// ]
// };