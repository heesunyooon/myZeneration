//---------------------학력OK--------------------
var education = document.getElementById("education");
var myPieChart = new Chart(education, {
    type: 'doughnut',
    data: {
    labels: ["고등학교 졸업", "대학교 (2,3,4년제) 졸업", "대학원 졸업"],
    datasets: [
        {
            data: [42, 64, 51],
            backgroundColor: ['rgb(7,77,129)', 'rgb(64,178,230)', 'rgb(32,203,194)'],
            hoverBackgroundColor: ['#2e59d9', '#17a673', '#2c9faf'],
            hoverBorderColor: "rgba(234, 236, 244, 1)",
    }],
    },
    options: {
        responsive:true,
        tooltips: { //그래프 위에 마우스 올리면 범례 설명
            backgroundColor: "rgb(255,255,255)",
            bodyFontColor: "#858796",
            borderColor: '#dddfeb',
            borderWidth: 1,
            xPadding: 15,
            yPadding: 15,
            displayColors: false,
            caretPadding: 10,
        },
        legend: {
            display: true, //범례나타내기 or 삭제하기 
            visible: true,
            align:'top',
        },
        cutoutPercentage: 70,//가운데 원 크기 
    },
});
//-------------------------------------------------

var ctx = document.getElementById("location");
var myPieChart = new Chart(ctx, {
    type: 'doughnut',
    data: {
    labels: ["서울", "부산", "광주"],
    datasets: [{
    data: [96, 62, 51],
    backgroundColor: ['rgb(7,77,129)', 'rgb(64,178,230)', 'rgb(32,203,194)'],
    hoverBackgroundColor: ['#2e59d9', '#17a673', '#2c9faf'],
    hoverBorderColor: "rgba(234, 236, 244, 1)",
    }],
    },
    options: {
        responsive:true,
        tooltips: { //그래프 위에 마우스 올리면 범례 설명
            backgroundColor: "rgb(255,255,255)",
            bodyFontColor: "#858796",
            borderColor: '#dddfeb',
            borderWidth: 1,
            xPadding: 15,
            yPadding: 15,
            displayColors: false,
            caretPadding: 10,
        },
        legend: {
            display: true, //범례나타내기 or 삭제하기 
            visible: true,
            align:'top',
        },
        cutoutPercentage: 70,//가운데 원 크기 
    },
});
//-------------------연봉 OK------------------------------

var salary = document.getElementById("salary");
var myPieChart = new Chart(salary, {
    type: 'doughnut',
    data: {
    labels: ["1000만원대", "2000만원대", "3000만원대","4000만원대","5000만원대","6000만원대","6000만원 초과"],
    datasets: [{
    data: [15, 50, 60,65,70,80,81],
    backgroundColor: ['rgb(7,77,129)', 'rgb(32,203,194)','rgb(64,178,230)','rgb(103,148,220)','rgb(103,113,220)','rgb(163,103,220)','rgb(87,64,247)'],
    hoverBackgroundColor: ['#2e59d9', '#17a673', '#2c9faf'],
    hoverBorderColor: "rgba(234, 236, 244, 1)",
    }],
    },
    options: {
        responsive:true,
        tooltips: { //그래프 위에 마우스 올리면 범례 설명
            backgroundColor: "rgb(255,255,255)",
            bodyFontColor: "#858796",
            borderColor: '#dddfeb',
            borderWidth: 1,
            xPadding: 15,
            yPadding: 15,
            displayColors: false,
            caretPadding: 10,
        },
        legend: {
            display: true, //범례나타내기 or 삭제하기 
            visible: true,
            align:'top',
        },
        cutoutPercentage: 70,//가운데 원 크기 
    },
});
//----------------------전공OK---------------------------

var major = document.getElementById("major");
var myPieChart = new Chart(major, {
    type: 'doughnut',
    data: {
    labels: ["인문/사회", "이학/공학", "예체능"],
    datasets: [{
    data: [84, 64, 51],
    backgroundColor: ['rgb(7,77,129)', 'rgb(64,178,230)', 'rgb(32,203,194)'],
    hoverBackgroundColor: ['#2e59d9', '#17a673', '#2c9faf'],
    hoverBorderColor: "rgba(234, 236, 244, 1)",
    }],
    },
    options: {
        responsive:true,
        tooltips: { //그래프 위에 마우스 올리면 범례 설명
            backgroundColor: "rgb(255,255,255)",
            bodyFontColor: "#858796",
            borderColor: '#dddfeb',
            borderWidth: 1,
            xPadding: 15,
            yPadding: 15,
            displayColors: false,
            caretPadding: 10,
        },
        legend: {
            display: true, //범례나타내기 or 삭제하기 
            visible: true,
            align:'top',
        },
        cutoutPercentage: 70,//가운데 원 크기 
    },
});
//-------------------------------------------------

var familyNo = document.getElementById("familyNo");
var familyNo = new Chart(familyNo, {
    type: 'doughnut',
    data: {
    labels: ["1인", "2인", "3인","4인","5인이상"],
    datasets: [{
    data: [15, 50, 60,65,37],
    backgroundColor: ['rgb(7,77,129)', 'rgb(32,203,194)','rgb(64,178,230)','rgb(103,148,220)','rgb(103,113,220)','rgb(163,103,220)','rgb(87,64,247)'],
    hoverBackgroundColor: ['#2e59d9', '#17a673', '#2c9faf'],
    hoverBorderColor: "rgba(234, 236, 244, 1)",
    }],
    },
    options: {
        responsive:true,
        tooltips: { //그래프 위에 마우스 올리면 범례 설명
            backgroundColor: "rgb(255,255,255)",
            bodyFontColor: "#858796",
            borderColor: '#dddfeb',
            borderWidth: 1,
            xPadding: 15,
            yPadding: 15,
            displayColors: false,
            caretPadding: 10,
        },
        legend: {
            display: true, //범례나타내기 or 삭제하기 
            visible: true,
            align:'top',
        },
        cutoutPercentage: 70,//가운데 원 크기 
    },
});
