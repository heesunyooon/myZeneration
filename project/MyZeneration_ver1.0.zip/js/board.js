var posts = new Array();
for(let i=0; i<240; i++){
    posts[i] =  {id: i, title: `${i} 번째 게시글`, author: "Author" + i, date: "2023-06-01", reply: "답변 완료", watchCount: "2"}
}

// prev와 next, 각 페이지네이션에 링크 달아주기.
// 글 작성에도 링크 달아주기.
// 데이터베이스에서 게시글 정보 가져오기.
// 댓글 정보에 관한 것은 추후 생각.

function boardPage(currentPage) { // 현재 페이지를 매개변수로 게시글/페이지네이션 표시.

    var tableBody = document.querySelector("#board-table tbody");
    tableBody.replaceChildren();

    let totalPost = posts.length; // 총 게시글 수
    let page_num = 10; // 페이지네이션 최대 수

    let totalPage = Math.ceil(totalPost / page_num); // 총 페이지네이션 수

    let pageGroup = Math.ceil(currentPage / page_num); // 현재 페이지가 몇 번째 그룹인지

    let lastPage = pageGroup * page_num;
    let firstPage = lastPage - (page_num - 1);
    if (lastPage > totalPage) { lastPage = totalPage; totalPage = Math.floor(totalPage) };
    if (firstPage < 0) { firstPage = 1 };

    let pages = document.querySelector(".paginate .pageNo");
    pages.replaceChildren();
  
    let prev = document.querySelector(".paginate #prev");
    if (currentPage>10) {
        prev.innerHTML = `<button id="prev" onclick=boardPage(${currentPage - 10})>◀</button>`
    } else if (currentPage <= 10) {
        prev.innerHTML = `<button id="prev" aria-invalid style="color:gray;")>◀</button>`
    }
    let next = document.querySelector(".paginate #next");
    if (Math.ceil(currentPage / 10) < Math.ceil(totalPage / 10)) {
        if (currentPage + 10 > totalPage) {
            next.innerHTML = `<button id="next" onclick=boardPage(${totalPage})>▶</button>`
        } else next.innerHTML = `<button id="next" onclick=boardPage(${currentPage + 10})>▶</button>`
    } else if (Math.ceil(currentPage / 10) >= Math.ceil(totalPage / 10)) {
        next.innerHTML = `<button id="next" aria-invalid style="color:gray;")>▶</button>`
    }

    for (let i = firstPage; i <= lastPage; i++) { // 페이지네이션 생성
        if (i == currentPage) {
            pages.innerHTML += `<button class="pageNumber currentPage" id="page_${i}">${i}</button>`
        } else pages.innerHTML += `<button class="pageNumber" id="page_${i}" onclick=boardPage(${i})>${i}</button>`
    }
  
    for (var i = totalPost-(currentPage-1)*10-1; i>totalPost-(currentPage*10)-1; i--) { // 글 생성
        var row = document.createElement("tr");

        var idCell = document.createElement("th"); // 글 번호
        idCell.setAttribute('class', 'text-center no');
        idCell.textContent=posts[i].id;
        idCell.scope="row"; 

        var titleCell = document.createElement("td"); // 글 제목
        titleCell.setAttribute('class', 'title');
        titleCell.innerHTML = `<a href="sub-board-watch.html">` + posts[i].title + "</a>";

        var authorCell = document.createElement("td"); // 글쓴이
        authorCell.setAttribute('class', 'text-center author');
        authorCell.textContent = posts[i].author;

        var dateCell = document.createElement("td"); // 작성일
        dateCell.setAttribute('class', 'text-center date');
        dateCell.textContent = posts[i].date;

        var replyCell = document.createElement("td"); // 답변 여부
        replyCell.setAttribute('class', 'text-center reply');
        replyCell.textContent = posts[i].reply;

        var recommendCell = document.createElement("td"); // 조회수
        recommendCell.setAttribute('class', 'text-center watchCount');
        recommendCell.textContent = posts[i].watchCount;

        row.appendChild(idCell);
        row.appendChild(titleCell);
        row.appendChild(authorCell);
        row.appendChild(dateCell);
        row.appendChild(replyCell);
        row.appendChild(recommendCell);

        tableBody.appendChild(row);
    }
}

window.onload = boardPage(1);