package mini_05_inheritance;
public class SonataLowGrade extends Sonata  {

	String color = "블루";
	String tire = "일반";
	String displacement = "2000";
	String handle = "일반";
	String tax = "1000";

	
	@Override
	public void getSpec() {
	System.out.println("*********************");
	System.out.printf("색상: %s\n", color);
	System.out.printf("타이어: %s\n", tire);
	System.out.printf("배기량: %s\n", displacement);
	System.out.printf("핸들: %s\n", handle);
	System.out.printf("타이어: %s\n", tire);
	System.out.printf("세금: %s\n", tax);
	System.out.println("*********************");
	}
}
