package mini_05_inheritance;


public abstract class  Sonata  {

	String color;
	String tire;
	String displacement;
	String handle;


	public abstract void getSpec();

}
