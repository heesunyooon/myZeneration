package mini_05_inheritance;


public class CarSpecs {

	public String color = "red/blue";
	public String tire = "normal/wide";
	public String displacement = "2000/2500";
	public String handle = "normal/power";
	
	
	
	
}
