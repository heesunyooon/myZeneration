package mini_05_inheritance;
public class MainClass {

	public static void main(String[] args) {
		SonataLowGrade sonataLow = new SonataLowGrade ();

		
		specPrint(sonataLow);
	}
	
	public static void specPrint(Sonata sonata) {
		sonata.getSpec();
	}

}
