package mini_01_array;
public class Addr {
	
	private String name;
	private String number;
	private String eMail;
	private String adress;
	private String group;
	
	public Addr (String name, String number, String eMail, String adress, String group){
	this.name = name;
	this.number = number;
	this.eMail = eMail;
	this.adress = adress;
	this.group = group;
	
	}
	
	public void printInfo() {
		System.out.println("이름: "+ name);
		System.out.println("전화번호: " + number);
		System.out.println("이메일: " + eMail);
		System.out.println("주소: " + adress);
		System.out.println("그룹: " + group);

	}
	//getter and setter
		public void setGroup(String group) {
		this.group = group;
	}
	
	
	
	
}
	

