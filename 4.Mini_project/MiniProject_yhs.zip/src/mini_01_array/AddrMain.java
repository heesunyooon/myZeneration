package mini_01_array;
public class AddrMain {

	public static void main(String[] args) {
		Addr addr = new Addr ("최윤호", "010-000-0000", "choi@gmail.com","서울", "친구");
		
		addr.printInfo();
		System.out.println("-----------------------------------");
		System.out.println("그룹정보변경");
		addr.setGroup("가족");
		System.out.println("-----------------------------------");
		addr.printInfo();
	
	}

}
