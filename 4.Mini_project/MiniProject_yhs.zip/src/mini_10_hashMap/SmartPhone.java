package mini_10_hashMap;

import java.util.*;

public class SmartPhone {
	
	Map<String, Addr> addrMap = new HashMap<String,Addr>();
	Set <Map.Entry<String, Addr>> entrySet = addrMap.entrySet();
	
	Scanner in = new Scanner (System.in);
	
	public String newKey() {
		System.out.println("핸드폰번호를 입력하세요");
		return in.nextLine();
	}
	
	public Addr newAddr() {
		System.out.print("이름을 입력해주세요: \n");
		String name = in.nextLine();
		System.out.print("번호를 입력해주세요: \n");
		String number = in.nextLine();
		System.out.print("이메일을 입력해주세요: \n");
		String eMail = in.nextLine();
		System.out.print("주소를 입력해주세요: \n");
		String address = in.nextLine();
		System.out.print("그룹(친구/가족) 입력해주세요: \n");
		String group = in.nextLine();
		return new Addr(name,number,eMail,address,group);
	}
	
	public void saveAddr() {
		String key = newKey();
		if(!addrMap.containsKey(key)) {
			addrMap.put(key,newAddr());
			System.out.println("저장되었습니다.");
			return;
		}
		else {
			System.out.println("이미 저장된 연락처입니다.");
		}
	}

	public void printAllAddr() {
		Iterator <Map.Entry<String, Addr>> iterator =  entrySet.iterator();
		if(iterator.hasNext()) {
			for(Map.Entry<String,Addr> temp : entrySet) {
				System.out.println("핸드폰번호"+temp.getKey());
				System.out.println("이름: "+temp.getValue().getName());
				System.out.println("번호: "+temp.getValue().getNumber());
				System.out.println("이메일: "+temp.getValue().geteMail());
				System.out.println("주소: "+temp.getValue().getAddress());
				System.out.println("그룹: "+temp.getValue().getGroup());
				System.out.println();
			}
		}
		else {
			System.out.println("등록된 연락처가 없습니다.");
			System.out.println();
		}
	}
	
	public void searchAddr() {
		System.out.println("검색할 이름을 입력하세요.");
		String recieve = in.nextLine();
		for (Map.Entry<String,Addr> temp : entrySet) {
			if(recieve.contentEquals(temp.getValue().getName())) {
				System.out.println("핸드폰번호"+temp.getKey());
				System.out.println("이름: "+temp.getValue().getName());
				System.out.println("번호: "+temp.getValue().getNumber());
				System.out.println("이메일: "+temp.getValue().geteMail());
				System.out.println("주소: "+temp.getValue().getAddress());
				System.out.println("그룹: "+temp.getValue().getGroup());
				return;
			}
		}
		System.out.println("검색결과가 없습니다.");
		System.out.println();
	}
	
	public void deleteAddr() {
		System.out.println("삭제할 이름을 입력해주세요.");
		String recieve = in.nextLine();
		for (Map.Entry<String,Addr> temp : entrySet) {
			if(recieve.contentEquals(temp.getValue().getName())){
				entrySet.remove(temp);
				System.out.println("삭제되었습니다.");
				return;
			}
		}
		System.out.println("조회결과가 없습니다.");
	}

	public void editAddr() {
		System.out.println("수정할 이름을 입력해주세요.");
		String recieve = in.nextLine();
		for (Map.Entry<String,Addr> temp : entrySet) {
			if(temp.getValue().getName().contentEquals(recieve)) {
				entrySet.remove(temp);
				saveAddr();
				return;
			}
		}
		System.out.println("조회결과가 없습니다.");
	}
}