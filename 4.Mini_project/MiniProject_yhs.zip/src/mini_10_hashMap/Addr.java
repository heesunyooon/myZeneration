package mini_10_hashMap;

public class Addr {
	
	private String name;
	private String number;
	private String eMail;
	private String address;
	private String group;
	
		
	public Addr (String name, String number, String eMail, String address, String group){
		this.name = name;
		this.number = number;
		this.eMail = eMail;
		this.address = address;
		this.group = group;
	}
	
	@Override
	public int hashCode() {
		return name.hashCode()+number.hashCode()+eMail.hashCode()+address.hashCode()+group.hashCode();
		
	}
	
	@Override
	public boolean equals (Object obj) {
		if(obj instanceof Addr) {
			Addr addr = (Addr) obj;
			return ((addr.name.equals(name))&&(addr.number.equals(number)) && (addr.eMail.contentEquals(address))&&(addr.group.equals(group)));
		}
		else return false;
	}
	
		
	//getter and setter
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	public String getNumber() {
		return number;
	}
	public void setNumber(String number) {
		this.number = number;
	}
	public String geteMail() {
		return eMail;
	}
	public void seteMail(String eMail) {
		this.eMail = eMail;
	}
	public String getAddress() {
		return address;
	}
	public void setAddress(String address) {
		this.address = address;
	}
	public String getGroup() {
		return group;
	}
	public void setGroup(String group) {
		this.group = group;
	}
	
	
}
