package mini_07_exceptionHandling;
import java.util.Scanner;
public class NumberTest {
	static Scanner in = new Scanner (System.in);
	public static void main(String[] args) {
		System.out.println("태어난 연도를 입력하세요.");
		try {
			isBirthInteger(in.nextLine());
		}
		catch(InputException e) {
			System.out.println("-----");
			e.printStackTrace();
		}
	}

	public static void isBirthInteger(String birth) throws InputException  {
		char charValue;
		for(int i=0; i<birth.length();i++) {
			charValue = birth.charAt(i);
			if(!(48<=charValue && charValue<=57)) {
				throw new InputException ("연도가 잘못입력되었습니다.");
			}
	}
		System.out.printf("%s년생", birth);
	}
}

	
