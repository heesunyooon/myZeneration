package mini_02_array;
import java.util.Scanner;
public class SmartPhoneMain {
	
	
	public static void main(String[] args) {
		SmartPhone smartphone = new SmartPhone();
		SmartPhoneMain smartphonemain = new SmartPhoneMain();
		
		System.out.println("#데이터 2개를 입력합니다.");
		for(int i=0; i<2; i++) {
		 smartphone.addrAddr(smartphone.inputAddrData());
		}
			
		boolean isStop=false;
		while (isStop==false) {
			isStop = smartphonemain.printMenu();	
		}	
}//end of Main
		
	
	//메뉴정보출력
	boolean printMenu () {
		
		SmartPhone smartphone = new SmartPhone();
		Scanner in = new Scanner (System.in);
		
		System.out.println("주소관리메뉴------------");
		System.out.println("1. 연락처 등록");
		System.out.println("2. 모든연락처 출력");
		System.out.println("3. 연락처검색");
		System.out.println("4. 연락처삭제");
		System.out.println("5. 연락처수정");
		System.out.println("6. 프로그램 종료");		
		System.out.println("------------------------");
		
		String recieve = in.nextLine();
		
		if (recieve.equals("1")){
			Addr addr = smartphone.inputAddrData();
			 smartphone.addrAddr(addr);
			 return false;
		}
		else if (recieve.equals("2")) {
			smartphone.printAllAddr ();
			return false;
		}
		else if (recieve.equals("3")) {
			System.out.println("검색할 이름을 입력해주세요.");
			smartphone.printAddr(smartphone.searchAddr(in.nextLine()));
			return false;
		}
		
		else if (recieve.equals("4")) {
			System.out.println("삭제할 이름을 입력해주세요.");
			smartphone.deleteAddr(in.nextLine());
			return false;
		}
		else if (recieve.equals("5")) {
			System.out.println("조회할 이름을 입력 후 수정할 정보를 입력해주세요.");		
			smartphone.editAddr(in.nextLine(), smartphone.inputAddrData());
			return false;
		}
		else if (recieve.equals("6")) {
			System.out.println("프로그램이 종료됩니다.");
			return true;
		}	
		else {
			System.out.println("다시 입력해주세요.");
			return false;
		}
	}
}
