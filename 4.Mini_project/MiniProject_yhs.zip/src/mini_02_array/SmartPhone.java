package mini_02_array;
import java.util.Scanner;

public class SmartPhone {

	Scanner in = new Scanner (System.in);
	static Addr[] addr = new Addr [10];
	
//-----------------------------------------------------외부입력 후 객체생성(↓)
	Addr inputAddrData() { 
		System.out.print("이름: ");
		String name = in.nextLine();
		System.out.print("전화번호: ");
		String number = in.nextLine();
		System.out.print("이메일: ");
		String eMail = in.nextLine();
		System.out.print("주소: ");
		String adress = in.nextLine();
		System.out.print("그룹(친구/가족): ");
		String group = in.nextLine();
		return new Addr (name, number, eMail, adress, group);
		}

//-----------------------------------------------------배열에 단일객체저장(↓)
	void addrAddr(Addr adr) { 
		boolean isNull=false;
		for (int i=0;i<addr.length; i++) {
			if (addr[i]==null) {
				addr[i] = adr;
				System.out.printf(">>>데이터가 저장되었습니다. (%d)\n", (i+1));
				isNull = true;
				break;
			}
		}
		if (isNull==false) System.out.println("저장할 수 있는 공간이 부족합니다.");		
	}
//-----------------------------------------------------단일 객체정보 출력(↓)
	void printAddr(Addr addr) { 
		if(addr!=null) {
		System.out.println("----------------------------------");
		System.out.printf("이름: %s\n", addr.getName());
		System.out.printf("전화번호: %s\n", addr.getNumber());
		System.out.printf("이메일: %s\n", addr.geteMail());
		System.out.printf("주소: %s\n", addr.getAdress());
		System.out.printf("그룹: %s\n", addr.getGroup());
		System.out.println("----------------------------------");
		}
		else {
			System.out.println("조회결과가 없습니다.");
		}
		
	}
//------------------------------------------------------------------모든객체 정보출력(↓)
	void printAllAddr () {	
			int x=0;
			for (int i=0;i<addr.length; i++) {
				if (addr[i]==null) {
					x=i;
					break;
				}
			}
			for (int j=0; j<x; j++) {
					printAddr(addr[j]);
			}		
		}
//-----------------------------------------------------이름 검색 후 정보 출력(↓)
	Addr searchAddr (String name) {
		for(int i=0; i<addr.length;i++) {
			if (addr[i].getName().contentEquals(name)) {
				return addr[i];
			}	
		}
		 System.out.println("조회결과가 없습니다.");
		 return null;
	}	
//-----------------------------------------------------연락처삭제(↓) >> 공부필요 boolean 타입 막 갈기지말기
	void deleteAddr(String name) { 
		
		int x=0;
		int y=0;
		for(int i=0;i<addr.length;i++) {
			if(addr[i].getName().contentEquals(name)) {
				x=i;
			}
			if(addr[i]==null) {
				y=i;
				
			}
		}
		//배열 내 객체가 없는 인덱스 확인 (=y)
		
		for (int i=x; i<y-1; i++) {
			addr[i] = addr[i+1];	//삭제된 그 인덱스(x)부터 차례대로 한 인덱스씩 앞으로 당김	
		}
		addr[y-1]=null;  // 맨끝 인덱스 객체 null로 초기화
		printAllAddr();	 //삭제 후 데이터 전체 출력
	}
//-----------------------------------------------------연락처수정(↓)
		void editAddr(String name, Addr newAddr) {		 
			boolean isSame = false;
				for(int i=0;i<addr.length;i++){
					if (addr[i].getName().contentEquals(name)) {
						addr[i]=newAddr;
						isSame = true;
						System.out.println("연락처수정이 완료되었습니다.");
						printAllAddr();
						break;
				}
			} 
			if (isSame == false) {
				System.out.println("조회결과가 없습니다.");
			}
		}
}
