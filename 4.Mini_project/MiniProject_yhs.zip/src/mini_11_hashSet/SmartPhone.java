package mini_11_hashSet;
import java.util.*;
public class SmartPhone {
	
	Set<Addr> addrSet = new HashSet<Addr>();
	Scanner in = new Scanner (System.in);
	
	public Addr newAddr() {
		System.out.print("이름을 입력해주세요: \n");
		String name = in.nextLine();
		System.out.print("번호를 입력해주세요: \n");
		String number = in.nextLine();
		System.out.print("이메일을 입력해주세요: \n");
		String eMail = in.nextLine();
		System.out.print("주소를 입력해주세요: \n");
		String address = in.nextLine();
		System.out.print("그룹(친구/가족) 입력해주세요: \n");
		String group = in.nextLine();
		return new Addr(name,number,eMail,address,group);
	}
	
	public void saveAddr() {
		if(addrSet.add(newAddr())) {
			System.out.println("저장되었습니다.");
			return;
		}
		else {
			System.out.println("이미 저장된 연락처입니다.");
			return;
		}
	}
	
	public void printAllAddr() {
		Iterator <Addr> iterator = addrSet.iterator();
		if(iterator.hasNext()) {
		for (Addr addr: addrSet) {
			System.out.println("이름: "+addr.getName());
			System.out.println("번호: "+addr.getNumber());
			System.out.println("이메일: "+addr.geteMail());
			System.out.println("주소: "+addr.getAddress());
			System.out.println("그룹: "+addr.getGroup());
			System.out.println();
			}
		}
		else {
			System.out.println("등록된 연락처가 없습니다.");
		}
	}
	
	public void searchAddr() {
		System.out.println("검색할 이름을 입력하세요.");
		String recieve = in.nextLine();
		for (Addr addr: addrSet) {
			if(recieve.contentEquals(addr.getName())) {
				System.out.println("이름: "+addr.getName());
				System.out.println("번호: "+addr.getNumber());
				System.out.println("이메일: "+addr.geteMail());
				System.out.println("주소: "+addr.getAddress());
				System.out.println("그룹: "+addr.getGroup());
				return;
			}
		}
			System.out.println("검색결과가 없습니다.");
			System.out.println();
		}
	
	public void deleteAddr() {
		System.out.println("삭제할 이름을 입력해주세요.");
		String recieve = in.nextLine();
		for (Addr addr: addrSet) {
			if(addr.getName().contentEquals(recieve)) {
				addrSet.remove(addr);
				System.out.println("삭제되었습니다.");
				return;
			}
		}
		System.out.println("조회결과가 없습니다.");
	}
	
	public void editAddr() {
		System.out.println("수정할 이름을 입력해주세요.");
		String recieve = in.nextLine();
			for (Addr addr : addrSet) {
				if(addr.getName().contentEquals(recieve)) {
					addrSet.remove(addr);
					saveAddr();
					System.out.println("연락처가 수정되었습니다.");
					return;
				}
			}
			System.out.println("조회결과가 없습니다.");
		}
	}

	
	
	
	

