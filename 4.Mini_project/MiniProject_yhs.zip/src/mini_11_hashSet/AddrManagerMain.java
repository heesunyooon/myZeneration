package mini_11_hashSet;

public class AddrManagerMain {
	
	public static void main(String[] args) {

		SmartPhone smartPhone = new SmartPhone();
		
		while(true) {
		System.out.println("주소관리메뉴------------");
		System.out.println("1. 연락처 등록");
		System.out.println("2. 모든연락처 출력");
		System.out.println("3. 연락처검색");
		System.out.println("4. 연락처삭제");
		System.out.println("5. 연락처수정");
		System.out.println("6. 프로그램 종료");		
		System.out.println("------------------------");
		
		String recieve = smartPhone.in.nextLine();

			if (recieve.contentEquals("1")) {
				smartPhone.saveAddr();
			}
			else if (recieve.contentEquals("2") ) {	
				smartPhone.printAllAddr();
			}
			else if (recieve.equals("3")) {
				smartPhone.searchAddr();
			}
			else if (recieve.contentEquals("4")) {
				smartPhone.deleteAddr();
			}
			else if (recieve.contentEquals("5")) {
				smartPhone.editAddr();
			}
			else if (recieve.contentEquals("6")) {
				System.out.println("프로그램이 종료됩니다.");
				break;
			}	
			else {
				System.out.print("다시 입력해주세요.");
			}	
		}
	}
}
