package mini_06_implementation;

public class CPhone implements IFunction{
	
	String accessSpeed = "5G";
	String TVremoteControl = "미탑재";

	@Override
	public void phoneCall() {
		System.out.println("전화가능합니다.");
	}//전화 송수신
	
	@Override
	public void accessSpeed () {
		if (this.accessSpeed.contentEquals("3G")) {
		System.out.println("불가능합니다. 3G입니다.");
		}
		else if (this.accessSpeed.contentEquals("4G")) {
			System.out.println("가능합니다. 4G입니다.");
		}
		else if (this.accessSpeed.contentEquals("5G")) {
			System.out.println("가능합니다. 5G입니다.");
		}
	}//접속속도
	
	@Override
	public void TVremoteControl () {
		if (this.TVremoteControl.contentEquals("미탑재")) {
		System.out.println("미 탑재 되어있습니다.");
	}
		else if (this.TVremoteControl.contentEquals("탑재")) {
		System.out.println("탑재 되어있습니다.");
		}
	}//TV리모콘
}
