package mini_06_implementation;
public class MainClass {

	public static void main(String[] args) {
	
		printSpec (new APhone());
		printSpec (new BPhone());
		printSpec (new CPhone());
	}
	
	public static void printSpec (IFunction iFunction) {
		iFunction.phoneCall();
		iFunction.accessSpeed();
		iFunction.TVremoteControl();
		System.out.println("--------------");
	}
}
