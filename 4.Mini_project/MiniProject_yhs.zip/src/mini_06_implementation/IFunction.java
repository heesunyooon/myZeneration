package mini_06_implementation;


public interface IFunction {
	 void phoneCall();
	 void accessSpeed();
	 void TVremoteControl();	
}
