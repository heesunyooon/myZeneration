package mini_04_inheritance;

public class Addr {
	
	private String name;
	private String number;
	private String eMail;
	private String address;
	private String group;
	
	Addr(){
	}
	
	public Addr (String name, String number, String eMail, String address, String group){
	this.name = name;
	this.number = number;
	this.eMail = eMail;
	this.address = address;
	this.group = group;
	
	}
	
	public void printInfo() {
		System.out.println("이름: "+ name);
		System.out.println("전화번호: " + number);
		System.out.println("이메일: " + eMail);
		System.out.println("주소: " + address);
		System.out.println("그룹: " + group);

	}
	//getter and setter

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public String getNumber() {
		return number;
	}

	public void setNumber(String number) {
		this.number = number;
	}

	public String geteMail() {
		return eMail;
	}

	public void seteMail(String eMail) {
		this.eMail = eMail;
	}

	public String getAddress() {
		return address;
	}

	public void setAdress(String adress) {
		this.address = adress;
	}

	public String getGroup() {
		return group;
	}

	public void setGroup(String group) {
		this.group = group;
	}
	
		
	}
	
	
	
	

	

