package mini_04_inheritance;
public class CustomerAddr extends Addr {
	private String customer;
	private String product;
	private String position;
	
	CustomerAddr(String name, String number, String eMail, String address, String group, String customer, String product, String position){
		super (name, number, eMail, address, group);
		this.customer = customer;
		this.product = product;
		this.position = position;
	}
	
		@Override
		public void printInfo() {
			System.out.println("이름: "+ getName());
			System.out.println("전화번호: " + getNumber());
			System.out.println("이메일: " + geteMail());
			System.out.println("주소: " + getAddress());
			System.out.println("그룹: " + getGroup());
			System.out.println("회사이름: "+ customer);
			System.out.println("부서명: "+ product);
			System.out.println("직급: "+ position);
	
		
	}
}
