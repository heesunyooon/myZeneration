package mini_03_inheritance;

import java.util.Scanner;

public class SmartPhone {

	Scanner in = new Scanner (System.in);
	static Addr[] addr = new Addr [10];
	static int count = 0;
	
//-----------------------------------------------------외부입력 후 객체생성(↓)
	Addr inputAddrData(String str) {
		System.out.print("이름: ");
		String name = in.nextLine();
		System.out.print("전화번호: ");
		String number = in.nextLine();
		System.out.print("이메일: ");
		String eMail = in.nextLine();
		System.out.print("주소: ");
		String address = in.nextLine();
		System.out.print("그룹: ");
		String group = in.nextLine();
		
	if(str.contentEquals("회사")) {	
		System.out.print("회사이름: ");
		String company = in.nextLine();
		System.out.print("부서이름: ");
		String department = in.nextLine();
		System.out.print("직급: ");
		String position = in.nextLine();
		return new CompanyAddr (name, number, eMail, address, group, company, department, position);
		}
	
	else if (str.contentEquals("거래처")) {
		System.out.print("거래처이름: ");
		String customer = in.nextLine();
		System.out.print("거래품목: ");
		String product = in.nextLine();
		System.out.print("직급: ");
		String position = in.nextLine();
		return new CustomerAddr (name, number, eMail, address, group, customer, product, position);
		}
	else return null;
	}
	
//-----------------------------------------------------외부입력 후 객체생성(↓)
//	Addr inputAddrData() { 
//		String name,number,eMail,address,group;
//		name=number=eMail=address=group=null;
//		
//		boolean isRight =false;
//			while (isRight == false) {
//				System.out.print("이름: ");
//				name = in.nextLine();
//				System.out.print("전화번호: ");
//				number = in.nextLine();
//				System.out.print("이메일: ");
//				eMail = in.nextLine();
//				System.out.print("주소: ");
//				address = in.nextLine();
//				System.out.print("그룹: ");
//				group = in.nextLine();
//		
//				if(group.contentEquals("회사")|group.contentEquals("거래처")) {
//					isRight = true;
//				}
//				else 
//					System.out.println("그룹 항목을 다시 입력해주세요. (회사/거래처)");
//				}
//		
//
//		if (group.contentEquals("회사")){
//			System.out.print("회사이름: ");
//			String company = in.nextLine();
//			System.out.print("부서이름: ");
//			String department = in.nextLine();
//			System.out.print("직급: ");
//			String position = in.nextLine();
//			return new CompanyAddr (name, number, eMail, address, group, company, department, position);
//			}
	
//		else if (group.contentEquals("거래처")){
//			System.out.print("거래처이름: ");
//			String customer = in.nextLine();
//			System.out.print("거래품목: ");
//			String product = in.nextLine();
//			System.out.print("직급: ");
//			String position = in.nextLine();
//			return new CustomerAddr (name, number, eMail, address, group, customer, product, position);
//			}
//		else
//			return null;
//	}

//-----------------------------------------------------배열에 단일객체저장(↓)
	void addrAddr(Addr adr) { 
		if (count>=10) {
			System.out.println("저장할 수 있는 공간이 부족합니다.");		
		}
		else{
		addr[count]=adr;
		count++;
		System.out.printf(">>>데이터가 저장되었습니다. (%d)\n", (count));
		}
	}
//-----------------------------------------------------단일 객체정보 출력(↓)
	void printAddr(Addr addr) { 
		if(addr!=null) {
		addr.printInfo();
		}
		else {
			System.out.println("다시 입력해주세요.");
		}
		
	}
//------------------------------------------------------------------모든객체 정보출력(↓)
	void printAllAddr () {	
		for (int i=0; i<count; i++) {
					printAddr(addr[i]);
			}		
		}
//-----------------------------------------------------이름 검색 후 정보 출력(↓)
	Addr searchAddr (String name) {
		for(int i=0; i<count;i++) {
			if (addr[i].getName().contentEquals(name)) {
				return addr[i];
			}	
		}
		 System.out.println("조회결과가 없습니다.");
		 return null;
	}	
//-----------------------------------------------------연락처삭제(↓) >> 공부필요 boolean 타입 막 갈기지말기
	void deleteAddr(String name) { 
		for(int i=0; i<count;i++) {
			if (addr[i].getName().contentEquals(name)) {
				for (int j=i; j<count; j++) {
					addr[j] = addr[j+1];
				}
				count--;
				return;
			}
		}
		 System.out.println("조회결과가 없습니다.");
	}
//-----------------------------------------------------연락처수정(↓)
	void editAddr(String name, Addr newAddr) {		 
		for(int i=0; i<count;i++) {
			if (addr[i].getName().contentEquals(name)) {
				addr[i]=newAddr;
				System.out.println("연락처수정이 완료되었습니다.");
				printAllAddr();
				return;
				}
			} 
				System.out.println("조회결과가 없습니다.");
	}
}

