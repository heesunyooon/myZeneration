package mini_03_inheritance;
public class CompanyAddr extends Addr {
	private String company;
	private String department;
	private String position;
	
	CompanyAddr(String name, String number, String eMail, String address, String group, String company, String department, String position){
		super (name, number, eMail, address, group);
		this.company = company;
		this.department = department;
		this.position = position;
	}
	
	@Override
	public void printInfo() {
		System.out.println("이름: "+ getName());
		System.out.println("전화번호: " + getNumber());
		System.out.println("이메일: " + geteMail());
		System.out.println("주소: " + getAddress());
		System.out.println("그룹: " + getGroup());
		System.out.println("회사이름: "+ company);
		System.out.println("부서명: "+ department);
		System.out.println("직급: "+ position);
	}
	
	

}
