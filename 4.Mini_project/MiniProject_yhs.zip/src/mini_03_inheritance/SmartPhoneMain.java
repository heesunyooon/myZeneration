package mini_03_inheritance;

import java.util.Scanner;
public class SmartPhoneMain {
	
	
	public static void main(String[] args) {
		SmartPhone sp = new SmartPhone();
		SmartPhoneMain spm = new SmartPhoneMain();
		
		System.out.println("#데이터 2개를 입력합니다.");
			sp.addrAddr(sp.inputAddrData("회사"));
			sp.addrAddr(sp.inputAddrData("거래처"));
		
			
		boolean isStop=false;
		while (isStop==false) {
			isStop = spm.printMenu();	
		}
	
	}//end of Main
	
	
	//메뉴정보출력
	boolean printMenu () {
		
		SmartPhone sp = new SmartPhone();
		Scanner in = new Scanner (System.in);
		
		System.out.println("주소관리메뉴------------");
		System.out.println("1. 연락처 등록 (회사)");
		System.out.println("2. 연락처 등록 (거래처)");
		System.out.println("3. 모든연락처 출력");
		System.out.println("4. 연락처검색");
		System.out.println("5. 연락처삭제");
		System.out.println("6. 연락처수정");
		System.out.println("7. 프로그램 종료");		
		System.out.println("------------------------");
		
		String recieve = in.nextLine();
		in.close();
		
		if (recieve.contentEquals("1")) {
			Addr addr = sp.inputAddrData("회사");
			 sp.addrAddr(addr);
			 return false;
		}
		else if (recieve.contentEquals("2") ) {
			Addr addr = sp.inputAddrData("거래처");
			 sp.addrAddr(addr);
			 return false;
		}
		else if (recieve.equals("3")) {
			sp.printAllAddr ();
			return false;
		}
		else if (recieve.contentEquals("4")) {
			System.out.println("검색할 이름을 입력해주세요.");
			sp.printAddr(sp.searchAddr(in.nextLine()));
			return false;
		}
		
		else if (recieve.contentEquals("5")) {
			System.out.println("삭제할 이름을 입력해주세요.");
			sp.deleteAddr(in.nextLine());
			return false;
		}
		else if (recieve.contentEquals("6")) {
			System.out.println("조회할 이름을 입력하세요.");
			String name = in.nextLine();
			System.out.println("저장할 그룹을 입력하세요. 회사/거래처");
			sp.editAddr(name, sp.inputAddrData(in.nextLine()));
			return false;
		}
		else if (recieve.contentEquals("7")) {
			System.out.println("프로그램이 종료됩니다.");
			return true;
		}	
		else {
			System.out.print("다시 입력해주세요.");
			return false;
		}	
	}
}
