package mini_09_arrayList;

public class Addr {
	
	private String name;
	private String number;
	private String eMail;
	private String address;
	private String group;
	
		
	public Addr (String name, String number, String eMail, String address, String group){
		this.name = name;
		this.number = number;
		this.eMail = eMail;
		this.address = address;
		this.group = group;
	}
		
	//getter and setter
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	public String getNumber() {
		return number;
	}
	public void setNumber(String number) {
		this.number = number;
	}
	public String geteMail() {
		return eMail;
	}
	public void seteMail(String eMail) {
		this.eMail = eMail;
	}
	public String getAddress() {
		return address;
	}
	public void setAddress(String address) {
		this.address = address;
	}
	public String getGroup() {
		return group;
	}
	public void setGroup(String group) {
		this.group = group;
	}
	
	
}
