package mini_09_arrayList;
import java.util.*;

public class SmartPhone {
	
	List<Addr> addrList = new ArrayList<Addr>();
	Scanner in = new Scanner (System.in);
	
	//연락처생성
	public Addr newAddr() {
		System.out.print("이름을 입력해주세요: \n");
		String name = in.nextLine();
		System.out.print("번호를 입력해주세요: \n");
		String number = in.nextLine();
		System.out.print("이메일을 입력해주세요: \n");
		String eMail = in.nextLine();
		System.out.print("주소를 입력해주세요: \n");
		String address = in.nextLine();
		System.out.print("그룹(친구/가족) 입력해주세요: \n");
		String group = in.nextLine();
		return new Addr(name,number,eMail,address,group);
	}
	
	//연락처저장
	public void saveAddr() {
		addrList.add(newAddr());
		System.out.println("저장되었습니다.");
		return;
	}
	
	//모든연락처 출력
	public void printAllAddr() {
		Iterator <Addr> iterator = addrList.iterator();
		if(iterator.hasNext()) {
			for (Addr addr: addrList) {
				System.out.println("이름: "+addr.getName());
				System.out.println("번호: "+addr.getNumber());
				System.out.println("이메일: "+addr.geteMail());
				System.out.println("주소: "+addr.getAddress());
				System.out.println("그룹: "+addr.getGroup());
				System.out.println();
			}
		}
		else {
			System.out.println("등록된 연락처가 없습니다.");
		}
	}
	
	//연락처 검색
	public void searchAddr() {
		System.out.println("검색할 이름을 입력하세요.");
		String recieve = in.nextLine();
		for (Addr addr: addrList) {
			if(recieve.contentEquals(addr.getName())) {
				System.out.println("이름: "+addr.getName());
				System.out.println("번호: "+addr.getNumber());
				System.out.println("이메일: "+addr.geteMail());
				System.out.println("주소: "+addr.getAddress());
				System.out.println("그룹: "+addr.getGroup());
				return;
			}
		}
			System.out.println("검색결과가 없습니다.");
			System.out.println();
		}
	
	//연락처삭제
	public void deleteAddr() {
		System.out.println("삭제할 이름을 입력해주세요.");
		String recieve = in.nextLine();
		for (Addr addr: addrList) {
			if(addr.getName().contentEquals(recieve)) {
				addrList.remove(addr);
				System.out.println("삭제되었습니다.");
				return;
		}
			else {
				System.out.println("조회결과가 없습니다.");
			}
		}
	}

	//연락처수정
	public void editAddr() {
		System.out.println("수정할 이름을 입력해주세요.");
		String recieve = in.nextLine();
			for (int i=0; i<addrList.size();i++) {
				if(addrList.get(i).getName().contentEquals(recieve)) {
					addrList.set(i, newAddr());
					System.out.println("연락처가 수정되었습니다.");
					return;
				}
			}
	}
}