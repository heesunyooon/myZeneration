package mini_09_arrayList;

public class AddrManagerMain {
	
	public static void main(String[] args) {

		SmartPhone smartPhone = new SmartPhone();
		while(true) {
			System.out.println("주소관리메뉴------------");
			System.out.println("1. 연락처 등록");
			System.out.println("2. 모든연락처 출력");
			System.out.println("3. 연락처검색");
			System.out.println("4. 연락처삭제");
			System.out.println("5. 연락처수정");
			System.out.println("8. 프로그램 종료");		
			System.out.println("------------------------");
		
			int recieve = smartPhone.in.nextInt();

			switch (recieve) {
				case 1: smartPhone.saveAddr();
				case 2: smartPhone.printAllAddr();
				case 3: smartPhone.searchAddr();
				case 4: smartPhone.deleteAddr();
				case 5: smartPhone.editAddr();
				case 6: 
				case 7:
				case 8: 
					System.out.println("프로그램이 종료됩니다.");
					return;
				default: System.out.print("다시 입력해주세요.");
			}			
		}
	}
}
