package mini_08_exceptionHandling;

public class InputException extends Exception{
	public InputException () {
		}
	public InputException(String msg) {
		super(msg);
	}
}
