package mini_08_exceptionHandling;
import java.util.Scanner;
public class InputTest {
	static Scanner in = new Scanner (System.in);
	public static void main(String[] args) {	
		 System.out.println("ID를 입력해주세요.");
			try{
				isIdAbnormal(in.nextLine());
			}
			catch(InputException e) {
				System.out.println(e.getMessage());
			}
	}
	public static boolean isIdAbnormal (String idLocal) throws InputException {
		char charValue;
		for(int i=0; i<idLocal.length();i++) {
			charValue = idLocal.charAt(i);
			if((idLocal==null)||(8<=charValue && charValue<=34)) {
				throw new InputException ("ID가 입력되지 않았습니다.");
			}
		}
		for(int i=0; i<idLocal.length();i++) {
			charValue = idLocal.charAt(i);
			if(!(47<=charValue && charValue<=57)&&!(65<=charValue && charValue<=122)) {
				throw new InputException ("ID가 잘못입력되었습니다.");
			}
		}
		System.out.println("ID: "+idLocal);
		return false;
	}
}

